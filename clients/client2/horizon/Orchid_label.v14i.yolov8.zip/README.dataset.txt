# Orchid_label > 2024-10-09 6:06am
https://universe.roboflow.com/kevinliu/orchid_label

Provided by a Roboflow user
License: CC BY 4.0

