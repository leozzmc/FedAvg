# Orchid_label > 2024-08-19 5:21am
https://universe.roboflow.com/kevinliu/orchid_label

Provided by a Roboflow user
License: CC BY 4.0

