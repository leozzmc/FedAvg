# Orchid_label > 2024-08-20 8:31am
https://universe.roboflow.com/kevinliu/orchid_label

Provided by a Roboflow user
License: CC BY 4.0

