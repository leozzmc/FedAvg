# Orchid_label > 2024-08-21 7:55am
https://universe.roboflow.com/kevinliu/orchid_label

Provided by a Roboflow user
License: CC BY 4.0

