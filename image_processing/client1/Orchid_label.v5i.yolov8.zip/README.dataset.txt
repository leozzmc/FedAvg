# Orchid_label > 2024-08-22 3:14am
https://universe.roboflow.com/kevinliu/orchid_label

Provided by a Roboflow user
License: CC BY 4.0

