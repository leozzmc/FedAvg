# Orchid_label > Client1 _top
https://universe.roboflow.com/kevinliu/orchid_label

Provided by a Roboflow user
License: CC BY 4.0

